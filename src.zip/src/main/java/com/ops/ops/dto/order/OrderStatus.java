package com.ops.ops.dto.order;

public enum OrderStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    CANCELLED,
    DELIVERED,
    RETURNED
}

